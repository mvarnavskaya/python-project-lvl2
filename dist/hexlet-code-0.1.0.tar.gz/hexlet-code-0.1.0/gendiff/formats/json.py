# -*- coding:utf-8 -*-

import json


def format_json(diff):
    return json.dumps(diff)
