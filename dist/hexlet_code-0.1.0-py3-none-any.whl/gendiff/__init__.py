# -*- coding:utf-8 -*-

from gendiff import generate_diff

__all__ = ('generate_diff',)
