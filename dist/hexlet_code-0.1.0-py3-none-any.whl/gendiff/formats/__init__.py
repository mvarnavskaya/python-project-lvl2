# -*- coding:utf-8 -*-

from gendiff.formats.formater import DEFAULT_STYLE, FORMATERS, call_formater

__all__ = ('DEFAULT_STYLE', 'FORMATERS', 'call_formater')
